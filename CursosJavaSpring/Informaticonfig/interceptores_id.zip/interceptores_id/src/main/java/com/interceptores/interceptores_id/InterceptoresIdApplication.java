package com.interceptores.interceptores_id;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InterceptoresIdApplication {

	public static void main(String[] args) {
		SpringApplication.run(InterceptoresIdApplication.class, args);
	}

}

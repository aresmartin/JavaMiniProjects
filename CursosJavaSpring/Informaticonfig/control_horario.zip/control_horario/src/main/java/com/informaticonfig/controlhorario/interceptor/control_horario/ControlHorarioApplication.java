package com.informaticonfig.controlhorario.interceptor.control_horario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControlHorarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControlHorarioApplication.class, args);
	}

}

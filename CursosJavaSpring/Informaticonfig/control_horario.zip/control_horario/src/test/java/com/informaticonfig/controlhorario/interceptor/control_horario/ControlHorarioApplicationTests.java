package com.informaticonfig.controlhorario.interceptor.control_horario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControlHorarioApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.archivos.excepciones.spring_excepcionesarchivos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringExcepcionesarchivosApplicationTests {

	@Test
	void contextLoads() {
	}

}

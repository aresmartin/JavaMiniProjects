package com.hybernate_jpa.hibernate_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}

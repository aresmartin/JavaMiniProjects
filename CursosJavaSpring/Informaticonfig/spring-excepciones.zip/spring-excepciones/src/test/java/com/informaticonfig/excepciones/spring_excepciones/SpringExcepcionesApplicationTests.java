package com.informaticonfig.excepciones.spring_excepciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringExcepcionesApplicationTests {

	@Test
	void contextLoads() {
	}

}

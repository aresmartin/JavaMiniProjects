package com.informaticonfig.excepciones.spring_excepciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringExcepcionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringExcepcionesApplication.class, args);
	}

}

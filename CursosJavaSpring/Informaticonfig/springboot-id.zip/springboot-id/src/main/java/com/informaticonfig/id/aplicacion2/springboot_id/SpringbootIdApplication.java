package com.informaticonfig.id.aplicacion2.springboot_id;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootIdApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootIdApplication.class, args);
	}

}

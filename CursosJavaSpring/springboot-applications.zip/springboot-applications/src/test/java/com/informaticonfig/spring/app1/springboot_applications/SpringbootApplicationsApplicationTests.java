package com.informaticonfig.spring.app1.springboot_applications;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootApplicationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
